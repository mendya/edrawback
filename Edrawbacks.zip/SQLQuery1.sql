﻿select * from status where path like '%test%'
delete from status where path like '%temp%'