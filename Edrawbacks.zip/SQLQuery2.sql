﻿select * from Export where style like '%test%'

select * from Users

select * from Import where style like '14337R%'

select * from status where username='signedpieces' and path not like '%import%'