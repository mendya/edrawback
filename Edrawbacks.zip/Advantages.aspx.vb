﻿
Partial Class Advantages
    Inherits System.Web.UI.Page

End Class
